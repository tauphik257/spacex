export const environment = {
  production: true,
  apiBaseURL: 'https://api.spacexdata.com/v3/launches?limit=100'
};

import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service/service.service';
import { Product } from '../controller/product';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  productsData: Product [] =  [];
  yearData: any;
  yearDataArray: Array<any> = [];
  currentIndex: any;
  currentYear: any;
  activeBtn:any;
  activeBtnLanding:any;
  constructor(
    private serverService: ServiceService
  ) { }

  ngOnInit(): void {
    this.getYearCollection();
  }
  getYearCollection(){
    this.serverService.getYearData('get', '')
    .subscribe((res: Response)=> {
      if(res){
        this.yearData = res;
        let arrHolder = [];
        this.yearData.map(function(obj:any){
          if(arrHolder.indexOf(obj.launch_year) == -1){
            arrHolder.push(obj.launch_year);
          }
        });
        this.yearDataArray = arrHolder;
        this.getProductData(this.yearData);
      }
    });
  }

  activeYear(activeYear, indexVal){
    this.currentYear = activeYear;
    this.currentIndex = indexVal;
    this.serverService.getYearData('get', "&launch_year="+activeYear+"")
    .subscribe((res: Response)=> {
      if(res){
        this.productsData.length = 0;
        this.getProductData(res);
      }
    });
  }

  getProductData(data:any){
    data.map((obj:any)=>{
      this.productsData.push(new Product(obj.mission_name, obj.flight_number, obj.mission_id, obj.launch_year, obj.launch_success, obj.links, obj.details))
    });
  }

  /** Successfull Launch  **/
  SuccessfullLaunch(data:any){
    this.activeBtn = data;
    let apiEnd = '';
    if(this.currentYear){
      apiEnd = "&launch_success="+data+"" + "&launch_year="+this.currentYear+"";
    }else{
      apiEnd = "&launch_success="+data+"";
    }
    this.serverService.getYearData('get', apiEnd)
    .subscribe((res: Response)=> {
      if(res){
        console.log(res);
        this.productsData.length = 0;
        this.getProductData(res);
      }
    });
  }

  /** Successfull Launch  **/
  SuccessfullLanding(data:any){
    this.activeBtnLanding = data;
    let apiEnd = '';
    if(this.currentYear){
      apiEnd = "&launch_success="+data+"" + "&launch_year="+this.currentYear+"";
    }else{
      apiEnd = "&launch_success="+data+"";
    }
    this.serverService.getYearData('get', apiEnd)
    .subscribe((res: Response)=> {
      if(res){
        console.log(res);
        this.productsData.length = 0;
        this.getProductData(res);
      }
    });
  }

  /** Clear Filter  **/
  clearFilter(){
    this.activeBtnLanding = -10;
    this.activeBtn = -10;
    this.currentIndex = -10;
    this.serverService.getYearData('get', '')
    .subscribe((res: Response)=> {
      if(res){
        this.productsData.length = 0;
        this.getProductData(res);
      }
    });
  }
}

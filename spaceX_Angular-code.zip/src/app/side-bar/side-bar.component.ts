import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service/service.service';

@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrls: ['./side-bar.component.css']
})
export class SideBarComponent implements OnInit {
  yearData: any;
  yearDataArray: Array<any> = [];
  constructor(
    private serverService: ServiceService
  ) { }

  ngOnInit(): void {
    
  }
  // getYearCollection(){
  //   this.serverService.getYearData('get', '')
  //   .subscribe((res: Response)=> {
  //     this.yearData = res;
  //     let arrHolder = [];
  //     this.yearData.map(function(obj){
  //       if(arrHolder.indexOf(obj.launch_year) == -1){
  //         arrHolder.push(obj.launch_year);
  //       }
  //     });
  //     this.yearDataArray = arrHolder;
  //     console.log(this.yearDataArray);
  //   })
  // }
}

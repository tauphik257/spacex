import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnChanges  {
  spaceXData:any;
  constructor() { }
  @Input() dashboardData: any;

  ngOnInit(): void {
    
  }
  // ngOnChanges() {
  //   this.spaceXData = this.dashboardData;
  //   console.log(this.dashboardData);
  // }
  ngOnChanges(changes: SimpleChanges): void {
    this.spaceXData = this.dashboardData;
  }

}

export class Product {
    constructor( 
        public mission_name: any, 
        public flight_number: any, 
        public mission_id: any,
        public launch_year: any,
        public launch_success: any,
        public links: any,
        public details: any
        ){}
}
